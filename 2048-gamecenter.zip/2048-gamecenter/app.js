//Dependencies
var express = require('express');
//var logfmt = require("logfmt");
var app = express();
var routes = require('./routes');
var user = require('./routes/user');
var http = require('http');
var path = require('path');

//app.use(logfmt.requestLogger());

var mongo = require('mongodb');

var mongoUri = process.env.MONGOLAB_URI ||
  process.env.MONGOHQ_URL ||
  'mongodb://localhost/local';


// all environments
app.set('port', process.env.PORT || 3000);
//app.set('views', path.join(__dirname, 'views'));
//app.set('view engine', 'jade');
//app.use(express.favicon());
//app.use(express.logger('dev'));
//app.use(express.json());
//app.use(express.urlencoded());
//app.use(express.methodOverride());
//app.use(app.router);
app.use(express.static(__dirname, 'public'));

// development only
//if ('development' == app.get('env')) {
//  app.use(express.errorHandler());
//}

app.get('/', routes.index);


app.get('/users', user.list);

app.get('/scores.json', function (req, res){
  mongo.Db.connect(mongoUri, function (err, db){
    db.collection("scores", function (er, col){
      var d = col.find({}).toArray(function(err, x){
        console.log(x);
      });
      col.find({}).sort("name").toArray(function(e, x){
        res.send(x);
      });
    });
  });
});

app.post('/submit.json', function (req, res){
  mongo.Db.connect(mongoUri, function (err, db){
    db.collection("scores", function (er, collection){

      var score = req.body.score;
      var name = req.body.playerName;
      collection.insert({"score": score, "playerName": name}, function (err, r){});
    });
  });
});

app.post('/', function (req, res){
    collection.find().sort({score:-1}).limit(100).toArray(function(err, cursor) {
    	var indexPage;
		if (!err) {
			indexPage += "<!DOCTYPE HTML><html><head><title>2048 Game Center</title></head><body><h1><2048 Game Center</h1><table><tr><th>User</th><th>Score</th><th>Timestamp</th></tr>";
			for (var count = 0; count < cursor.length; count++) {
				indexPage += "<tr><td>" + cursor[count].username + "<tr><td>" + cursor[count].score + "<tr><td>" + cursor[count].created_at + "<tr><td>";
			}
			indexPage += "</table></body></html>"
			res.send(indexPage);
		}
		else {
			//executed when there is an error (shouldn't happen though)
		}
	});
});

http.createServer(app).listen(app.get('port'), function(){
  console.log('Express server listening on port ' + app.get('port'));
});